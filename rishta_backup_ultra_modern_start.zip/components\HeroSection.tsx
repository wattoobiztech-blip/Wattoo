'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, useAnimationFrame } from '@/components/ui/Motion'
import { ArrowRight, Heart, Users, Shield, Star, Zap, MapPin, Crown, Verified, Search } from 'lucide-react'
import Image from 'next/image'
import { PROFILE_IMAGES, FALLBACK_IMAGES, getImageSrc } from '@/lib/image-constants'

export default function HeroSection() {
  const [isLoaded, setIsLoaded] = useState(false)

  const profiles = [
    { id: 1, name: 'Ayesha Khan', age: 26, profession: 'Software Engineer', location: 'Karachi', image: getImageSrc(PROFILE_IMAGES.ayesha, FALLBACK_IMAGES.profiles.ayesha), verified: true, premium: true },
    { id: 2, name: 'Ahmed Ali', age: 29, profession: 'Doctor', location: 'Lahore', image: getImageSrc(PROFILE_IMAGES.ahmed, FALLBACK_IMAGES.profiles.ahmed), verified: true, premium: false },
    { id: 3, name: 'Fatima Sheikh', age: 24, profession: 'Teacher', location: 'Islamabad', image: getImageSrc(PROFILE_IMAGES.fatima, FALLBACK_IMAGES.profiles.fatima), verified: true, premium: true },
    { id: 4, name: 'Hassan Malik', age: 31, profession: 'Business Owner', location: 'Rawalpindi', image: getImageSrc(PROFILE_IMAGES.hassan, FALLBACK_IMAGES.profiles.hassan), verified: true, premium: false },
    { id: 5, name: 'Zara Butt', age: 27, profession: 'Marketing Manager', location: 'Faisalabad', image: getImageSrc(PROFILE_IMAGES.zara, FALLBACK_IMAGES.profiles.zara), verified: true, premium: true },
    { id: 6, name: 'Usman Chaudhry', age: 28, profession: 'Chartered Accountant', location: 'Multan', image: getImageSrc(PROFILE_IMAGES.usman, FALLBACK_IMAGES.profiles.usman), verified: true, premium: false },
  ]

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  // Profile Carousel Animation Logic
  const [isHovered, setIsHovered] = useState(false)
  const xTranslation = useRef(0)
  const containerRef = useRef<HTMLDivElement>(null)

  useAnimationFrame((t: number, delta: number) => {
    if (!containerRef.current || isHovered) return
    xTranslation.current -= 0.5 // Slower, smoother
    if (Math.abs(xTranslation.current) >= containerRef.current.scrollWidth / 3) {
      xTranslation.current = 0
    }
    containerRef.current.style.transform = `translateX(${xTranslation.current}px)`
  })

  return (
    <section className="relative min-h-screen overflow-hidden bg-slate-50 flex flex-col pt-24 lg:pt-32">
      {/* Modern Mesh Gradient Background */}
      <div className="absolute inset-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full bg-primary-200/40 mix-blend-multiply filter blur-[80px] opacity-70 animate-blob"></div>
        <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full bg-secondary-200/40 mix-blend-multiply filter blur-[80px] opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-32 left-[20%] w-[60%] h-[60%] rounded-full bg-pink-200/40 mix-blend-multiply filter blur-[80px] opacity-70 animate-blob animation-delay-4000"></div>
        <div className="absolute inset-0 bg-[url('/noise.png')] opacity-[0.03] mix-blend-overlay"></div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-20 container mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-16">

          {/* Left Content - Typography & CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center lg:text-left space-y-8"
          >
            <div className="inline-flex items-center space-x-2 bg-white/60 backdrop-blur-sm border border-pink-100 rounded-full py-2 px-4 shadow-sm mb-4">
              <span className="flex h-2 w-2 rounded-full bg-primary-500 animate-pulse"></span>
              <span className="text-sm font-semibold text-primary-700 tracking-wide uppercase">#1 Trusted Matrimonial App</span>
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-heading font-extrabold tracking-tight text-slate-900 leading-[1.1]">
              Find Your <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-secondary-600">Soulmate</span>
              <span className="relative inline-block ml-4">
                today
                <svg className="absolute w-full h-3 -bottom-1 left-0 text-primary-300 -z-10" viewBox="0 0 100 10" preserveAspectRatio="none">
                  <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" />
                </svg>
              </span>
            </h1>

            <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto lg:mx-0 font-light leading-relaxed">
              Join millions of happy couples. Our AI-powered matchmaking algorithm connects you with compatible partners based on shared values and interests.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="group relative px-8 py-4 bg-slate-900 text-white rounded-full font-bold text-lg shadow-xl shadow-slate-900/20 overflow-hidden"
              >
                <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-primary-500 to-secondary-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <span className="relative flex items-center gap-2">
                  Create Profile <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-8 py-4 bg-white text-slate-700 border border-slate-200 rounded-full font-bold text-lg shadow-sm hover:shadow-md transition-all hover:bg-slate-50 flex items-center gap-2 justify-center"
              >
                <Search className="w-5 h-5" /> Browse Matches
              </motion.button>
            </div>

            <div className="flex items-center justify-center lg:justify-start gap-8 pt-8 opacity-80 grayscale hover:grayscale-0 transition-all duration-500">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Featured in</p>
              {/* Placeholders for logos, can be text for now */}
              <span className="text-slate-400 font-serif font-bold text-xl">VOGUE</span>
              <span className="text-slate-400 font-sans font-bold text-xl">Forbes</span>
              <span className="text-slate-400 font-mono font-bold text-xl">WIRED</span>
            </div>
          </motion.div>

          {/* Right Side - Visuals */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative h-[500px] lg:h-[700px] flex items-center justify-center"
          >
            {/* Main Image Container with Abstract Shapes */}
            <div className="relative w-full max-w-[500px] aspect-[4/5]">
              {/* Floating Elements */}
              <motion.div
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-10 -left-10 z-30 bg-white p-4 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] flex items-center gap-3 border border-pink-50"
              >
                <div className="bg-pink-100 p-2 rounded-full"><Heart className="w-6 h-6 text-pink-500 fill-pink-500" /></div>
                <div>
                  <p className="text-xs text-slate-500 font-medium">Daily Matches</p>
                  <p className="text-lg font-bold text-slate-800">250+</p>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute bottom-20 -right-5 z-30 bg-white p-4 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] flex items-center gap-3 border border-pink-50"
              >
                <div className="bg-green-100 p-2 rounded-full"><Verified className="w-6 h-6 text-green-500" /></div>
                <div>
                  <p className="text-xs text-slate-500 font-medium">Verified Profiles</p>
                  <p className="text-lg font-bold text-slate-800">100%</p>
                </div>
              </motion.div>

              {/* Main Image Mask */}
              <div className="relative w-full h-full rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl bg-white rotate-2 hover:rotate-0 transition-transform duration-700 ease-out-expo">
                <Image
                  src="/images/hero/pakistani-couple.png"
                  alt="Happy Couple"
                  fill
                  className="object-cover"
                  priority
                />
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/30"></div>
              </div>

              {/* Decor Dots */}
              <div className="absolute -z-10 top-[-20px] right-[-20px] w-24 h-24 bg-pattern-dots opacity-20"></div>
            </div>
          </motion.div>

        </div>
      </div>

      {/* Bottom Profile Carousel - Glassmorphism */}
      <div className="relative z-30 w-full mb-8 border-y border-white/20 bg-white/30 backdrop-blur-md">
        <div
          className="relative overflow-hidden group py-6"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="absolute inset-y-0 left-0 w-32 md:w-64 bg-gradient-to-r from-slate-50 via-slate-50/80 to-transparent z-10 pointer-events-none" />
          <div className="absolute inset-y-0 right-0 w-32 md:w-64 bg-gradient-to-l from-slate-50 via-slate-50/80 to-transparent z-10 pointer-events-none" />

          <div
            ref={containerRef}
            className="flex space-x-6 whitespace-nowrap px-4 w-max"
          >
            {[...profiles, ...profiles, ...profiles].map((profile, index) => (
              <motion.div
                key={`${profile.id}-${index}`}
                whileHover={{ y: -5, scale: 1.02 }}
                className="w-[320px] h-[100px] bg-white rounded-2xl p-3 flex items-center space-x-4 shadow-sm border border-slate-100 hover:shadow-lg transition-all duration-300 cursor-pointer"
              >
                <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0">
                  <Image src={profile.image} alt={profile.name} fill className="object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <h4 className="text-slate-900 font-bold text-sm truncate">{profile.name}</h4>
                    {profile.verified && <Verified className="w-3 h-3 text-blue-500 shrink-0" />}
                    {profile.premium && <Crown className="w-3 h-3 text-amber-500 shrink-0" />}
                  </div>
                  <p className="text-slate-500 text-xs truncate">{profile.profession}</p>
                  <p className="text-slate-400 text-[10px] mt-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {profile.location}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
