# Rishta Matrimonial - Deployment Package

This is a complete deployment package for the Rishta Matrimonial website.

## What's Included

- Complete Next.js frontend application (Port 3002)
- Node.js backend API
- MySQL database schema and seed data
- Docker configuration for easy deployment
- PM2 ecosystem configuration
- Build fix script (fix-build-error.sh)
- Deployment scripts for port 3002
- Nginx configuration
- All documentation (English & Urdu)

## Quick Start

### If You Had Build Error (IMPORTANT!)

If you encountered this error on your server:
`
Error: Unexpected token motion. Expected jsx identifier
`

**Run the fix script first:**

`ash
# Make script executable
chmod +x fix-build-error.sh

# Run the fix script
./fix-build-error.sh
`

This will automatically:
1. Clean build cache and node_modules
2. Clear npm cache
3. Reinstall dependencies
4. Build the application

For detailed troubleshooting in Urdu, see **BUILD_FIX_GUIDE_URDU.md**

### Normal Deployment (Port 3002)

See **DEPLOYMENT_INSTRUCTIONS.md** for detailed setup instructions.

### Fastest Way to Deploy with PM2

`ash
# Run deployment script
chmod +x deploy-port-3002.sh
./deploy-port-3002.sh
`

The application will be available at:
- Frontend: http://your-server-ip:3002
- Backend: http://your-server-ip:5000

### Using Docker

`ash
# Using Docker (recommended)
docker-compose up -d
`

## Latest Features

✅ **BUILD FIX:** Fixed framer-motion syntax error
✅ **PORT 3002:** Application configured for port 3002
✅ Complete user profile management
✅ Match browsing and filtering system
✅ Subscription management with payment integration
✅ Settings and preferences
✅ Profile viewing with image galleries
✅ Header navigation on all pages
✅ Logo linking to home page
✅ Pakistani localization (cities, castes, currency)
✅ Modern glassmorphism UI design
✅ Fully responsive design
✅ PM2 process management
✅ Urdu documentation

## Important Files

### Build Fix & Troubleshooting
- **fix-build-error.sh** - Automatic build error fix script
- **BUILD_FIX_GUIDE_URDU.md** - Detailed troubleshooting guide (Urdu)

### Port 3002 Configuration
- **deploy-port-3002.sh** - Deployment script for port 3002
- **start-3002.sh** - Start script for port 3002
- **ecosystem.config.js** - PM2 configuration
- **PORT_3002_SETUP.md** - Port configuration details
- **QUICK_START_URDU.md** - Quick start guide (Urdu)

## Documentation

- **BUILD_FIX_GUIDE_URDU.md** - Build error troubleshooting (Urdu)
- **QUICK_START_URDU.md** - Quick start guide (Urdu)
- **PORT_3002_SETUP.md** - Port 3002 configuration
- **DEPLOYMENT_INSTRUCTIONS.md** - Quick start guide
- **DEPLOYMENT.md** - Detailed deployment guide
- **README.md** - Project overview
- **docs/** - Additional documentation

## Requirements

- Node.js 18.x or higher
- npm 9.x or higher
- MySQL 8.0 or higher
- Docker (optional, but recommended)
- PM2 (optional, for process management)

## Troubleshooting

### Build Error
If you see: Error: Unexpected token 'motion'
- Run: ./fix-build-error.sh
- See: BUILD_FIX_GUIDE_URDU.md

### Port Already in Use
If port 3002 is busy:
- Check: lsof -i :3002
- Kill: kill -9 <PID>
- Or use different port in package.json

### Node Version Issues
Check versions:
`ash
node --version  # Should be 18.x+
npm --version   # Should be 9.x+
`

## Support

For detailed documentation, see the included files:
- **BUILD_FIX_GUIDE_URDU.md** - Build error fixes (Urdu)
- **QUICK_START_URDU.md** - Quick start (Urdu)
- **DEPLOYMENT_INSTRUCTIONS.md** - Quick deployment
- **DEPLOYMENT.md** - Detailed deployment
- **PORT_3002_SETUP.md** - Port configuration
- **docs/IMAGE_STORAGE.md** - Image system
- **docs/LOGO_USAGE.md** - Logo guidelines

## What Was Fixed

### Build Error Fix
The previous package had a build error in components/dashboard/profile/PhotosStep.tsx:
`
Error: Unexpected token motion. Expected jsx identifier
`

**Fixed by:**
- Removed problematic motion.div components from framer-motion
- Fixed JSX structure issues
- Updated deprecated substr() to substring()
- Cleaned up unused imports

The fix maintains all functionality while resolving the build error.

---
Package created: 2026-02-01 23:55:11
**Build Error Fixed ✓**
**Port 3002 Configured ✓**
**Ready for Deployment ✓**
