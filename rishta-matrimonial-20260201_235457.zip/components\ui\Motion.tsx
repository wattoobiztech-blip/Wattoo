// Simple motion wrapper to replace framer-motion
// This provides basic animations using CSS transitions

import React from 'react';

export const motion = {
  div: React.forwardRef<HTMLDivElement, any>(({ children, className, style, ...props }, ref) => (
    <div ref={ref} className={className} style={style} {...props}>
      {children}
    </div>
  )),
  
  button: React.forwardRef<HTMLButtonElement, any>(({ children, className, style, ...props }, ref) => (
    <button ref={ref} className={className} style={style} {...props}>
      {children}
    </button>
  )),
  
  span: React.forwardRef<HTMLSpanElement, any>(({ children, className, style, ...props }, ref) => (
    <span ref={ref} className={className} style={style} {...props}>
      {children}
    </span>
  )),
  
  label: React.forwardRef<HTMLLabelElement, any>(({ children, className, style, ...props }, ref) => (
    <label ref={ref} className={className} style={style} {...props}>
      {children}
    </label>
  )),
  
  p: React.forwardRef<HTMLParagraphElement, any>(({ children, className, style, ...props }, ref) => (
    <p ref={ref} className={className} style={style} {...props}>
      {children}
    </p>
  )),
};

export const AnimatePresence: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <>{children}</>
);

motion.div.displayName = 'motion.div';
motion.button.displayName = 'motion.button';
motion.span.displayName = 'motion.span';
motion.label.displayName = 'motion.label';
motion.p.displayName = 'motion.p';
