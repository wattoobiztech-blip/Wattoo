'use client'

import { useState, useEffect } from 'react'
import { ArrowRight, Heart, Sparkles, Shield, Star, Users, CheckCircle, TrendingUp, Zap } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { PROFILE_IMAGES, FALLBACK_IMAGES, getImageSrc } from '@/lib/image-constants'

export default function HeroSection() {
  const [activeIndex, setActiveIndex] = useState(0)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  const stats = [
    { value: '50K+', label: 'Active Users', icon: Users },
    { value: '15K+', label: 'Success Stories', icon: Heart },
    { value: '98%', label: 'Match Rate', icon: TrendingUp },
    { value: '100%', label: 'Verified', icon: Shield },
  ]

  const features = [
    { icon: Sparkles, text: 'AI-Powered Matching' },
    { icon: Shield, text: '100% Verified Profiles' },
    { icon: Heart, text: 'Privacy Protected' },
  ]

  const testimonials = [
    { name: 'Ayesha & Ahmed', text: 'Found my perfect match!', image: getImageSrc(PROFILE_IMAGES.ayesha, FALLBACK_IMAGES.profiles.ayesha) },
    { name: 'Fatima & Hassan', text: 'Best decision ever!', image: getImageSrc(PROFILE_IMAGES.fatima, FALLBACK_IMAGES.profiles.fatima) },
    { name: 'Zara & Usman', text: 'Happily married now!', image: getImageSrc(PROFILE_IMAGES.zara, FALLBACK_IMAGES.profiles.zara) },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 20 - 10,
        y: (e.clientY / window.innerHeight) * 20 - 10,
      })
    }
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  return (
    <section className="relative min-h-screen overflow-hidden bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f12_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f12_1px,transparent_1px)] bg-[size:64px_64px]"></div>
      
      {/* Gradient Orbs with Parallax */}
      <div 
        className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"
        style={{ transform: `translate(${mousePosition.x}px, ${mousePosition.y}px)` }}
      ></div>
      <div 
        className="absolute top-0 right-1/4 w-96 h-96 bg-pink-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"
        style={{ transform: `translate(${-mousePosition.x}px, ${mousePosition.y}px)` }}
      ></div>
      <div 
        className="absolute -bottom-32 left-1/2 w-96 h-96 bg-blue-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000"
        style={{ transform: `translate(${mousePosition.x * 0.5}px, ${-mousePosition.y * 0.5}px)` }}
      ></div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${5 + Math.random() * 10}s`,
            }}
          ></div>
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          
          {/* Left Content */}
          <div className="text-center lg:text-left space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white/90 text-sm font-medium">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span>Pakistan's Most Trusted Platform</span>
              <div className="flex items-center gap-1 ml-2 px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></div>
                <span>Live</span>
              </div>
            </div>

            {/* Main Heading with Gradient */}
            <h1 className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-black leading-[1.1] tracking-tight">
              <span className="block text-white">Find Your</span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 animate-gradient-x">
                Perfect Match
              </span>
              <span className="block text-white/80 text-3xl sm:text-4xl lg:text-5xl mt-2 font-light">
                in Pakistan
              </span>
            </h1>

            {/* Description */}
            <p className="text-lg sm:text-xl text-white/70 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Join <span className="text-white font-semibold">50,000+</span> verified members finding their soulmates through our AI-powered matchmaking platform.
            </p>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 text-white/80 text-sm hover:bg-white/10 transition-all duration-300"
                >
                  <feature.icon className="w-4 h-4 text-purple-400" />
                  <span>{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
              <Link href="/register">
                <button className="group relative px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-2xl font-bold text-lg shadow-2xl shadow-purple-500/50 hover:shadow-purple-500/70 transition-all duration-300 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <span className="relative flex items-center justify-center gap-2">
                    Start Free Today
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </span>
                </button>
              </Link>

              <Link href="/dashboard/search">
                <button className="px-8 py-4 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-2xl font-bold text-lg hover:bg-white/20 transition-all duration-300 flex items-center justify-center gap-2">
                  <Heart className="w-5 h-5" />
                  Browse Profiles
                </button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-8">
              {stats.map((stat, index) => (
                <div
                  key={index}
                  className="text-center p-4 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300"
                >
                  <stat.icon className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                  <div className="text-2xl sm:text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-xs sm:text-sm text-white/60 mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - 3D Card Stack */}
          <div className="relative h-[600px] flex items-center justify-center lg:justify-center">
            {/* Main Card Container - Centered */}
            <div className="relative w-full max-w-md mx-auto">
              {/* Floating Success Stories */}
              <div className="absolute -top-10 -left-10 z-20 bg-gradient-to-br from-green-400 to-emerald-500 p-4 rounded-2xl shadow-2xl shadow-green-500/50 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-white">
                    <div className="text-2xl font-bold">15,000+</div>
                    <div className="text-sm opacity-90">Success Stories</div>
                  </div>
                </div>
              </div>

              {/* Floating Active Users */}
              <div className="absolute -bottom-10 -right-10 z-20 bg-gradient-to-br from-purple-500 to-pink-500 p-4 rounded-2xl shadow-2xl shadow-purple-500/50 animate-float animation-delay-2000">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-white">
                    <div className="text-2xl font-bold">2,500+</div>
                    <div className="text-sm opacity-90">Online Now</div>
                  </div>
                </div>
              </div>

              {/* Profile Cards Stack - Centered */}
              <div className="relative w-full h-[500px] flex items-center justify-center">
                {testimonials.map((testimonial, index) => (
                  <div
                    key={index}
                    className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm transition-all duration-700 ${
                      index === activeIndex
                        ? 'opacity-100 scale-100 rotate-0 z-10'
                        : index === (activeIndex + 1) % testimonials.length
                        ? 'opacity-70 scale-95 rotate-3 translate-y-4 z-5'
                        : 'opacity-40 scale-90 rotate-6 translate-y-8 z-0'
                    }`}
                  >
                    <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-2xl">
                      {/* Profile Image - Centered */}
                      <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden mb-6 shadow-xl mx-auto">
                        <Image
                          src={testimonial.image}
                          alt={testimonial.name}
                          fill
                          className="object-cover object-center"
                          priority
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                        
                        {/* Verified Badge */}
                        <div className="absolute top-4 right-4 bg-blue-500 p-2 rounded-full shadow-lg">
                          <CheckCircle className="w-5 h-5 text-white" />
                        </div>

                        {/* Name Overlay */}
                        <div className="absolute bottom-4 left-4 right-4 text-center">
                          <h3 className="text-white text-2xl font-bold mb-1">{testimonial.name}</h3>
                          <div className="flex items-center justify-center gap-2 text-white/80 text-sm">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span>{testimonial.text}</span>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-3">
                        <button className="flex-1 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 flex items-center justify-center gap-2">
                          <Heart className="w-5 h-5" />
                          Like
                        </button>
                        <button className="flex-1 py-3 bg-white/10 backdrop-blur-sm text-white border border-white/20 rounded-xl font-semibold hover:bg-white/20 transition-all duration-300">
                          View Profile
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination Dots - Centered */}
              <div className="absolute -bottom-16 left-1/2 transform -translate-x-1/2 flex gap-2 z-20">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index === activeIndex
                        ? 'bg-purple-500 w-8'
                        : 'bg-white/30 hover:bg-white/50'
                    }`}
                  ></button>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="currentColor"
            className="text-white/5"
          />
        </svg>
      </div>
    </section>
  )
}
