// Simple motion wrapper to replace framer-motion
// This provides basic animations using CSS transitions

import React from 'react';

export const motion = {
  div: React.forwardRef<HTMLDivElement, any>(({ children, className, style, ...props }, ref) => (
    <div ref={ref} className={className} style={style} {...props}>
      {children}
    </div>
  )),
  
  button: React.forwardRef<HTMLButtonElement, any>(({ children, className, style, ...props }, ref) => (
    <button ref={ref} className={className} style={style} {...props}>
      {children}
    </button>
  )),
  
  span: React.forwardRef<HTMLSpanElement, any>(({ children, className, style, ...props }, ref) => (
    <span ref={ref} className={className} style={style} {...props}>
      {children}
    </span>
  )),
  
  label: React.forwardRef<HTMLLabelElement, any>(({ children, className, style, ...props }, ref) => (
    <label ref={ref} className={className} style={style} {...props}>
      {children}
    </label>
  )),
  
  p: React.forwardRef<HTMLParagraphElement, any>(({ children, className, style, ...props }, ref) => (
    <p ref={ref} className={className} style={style} {...props}>
      {children}
    </p>
  )),

  tr: React.forwardRef<HTMLTableRowElement, any>(({ children, className, style, ...props }, ref) => (
    <tr ref={ref} className={className} style={style} {...props}>
      {children}
    </tr>
  )),

  td: React.forwardRef<HTMLTableCellElement, any>(({ children, className, style, ...props }, ref) => (
    <td ref={ref} className={className} style={style} {...props}>
      {children}
    </td>
  )),

  th: React.forwardRef<HTMLTableHeaderCellElement, any>(({ children, className, style, ...props }, ref) => (
    <th ref={ref} className={className} style={style} {...props}>
      {children}
    </th>
  )),

  table: React.forwardRef<HTMLTableElement, any>(({ children, className, style, ...props }, ref) => (
    <table ref={ref} className={className} style={style} {...props}>
      {children}
    </table>
  )),

  tbody: React.forwardRef<HTMLTableSectionElement, any>(({ children, className, style, ...props }, ref) => (
    <tbody ref={ref} className={className} style={style} {...props}>
      {children}
    </tbody>
  )),

  thead: React.forwardRef<HTMLTableSectionElement, any>(({ children, className, style, ...props }, ref) => (
    <thead ref={ref} className={className} style={style} {...props}>
      {children}
    </thead>
  )),

  ul: React.forwardRef<HTMLUListElement, any>(({ children, className, style, ...props }, ref) => (
    <ul ref={ref} className={className} style={style} {...props}>
      {children}
    </ul>
  )),

  li: React.forwardRef<HTMLLIElement, any>(({ children, className, style, ...props }, ref) => (
    <li ref={ref} className={className} style={style} {...props}>
      {children}
    </li>
  )),

  form: React.forwardRef<HTMLFormElement, any>(({ children, className, style, ...props }, ref) => (
    <form ref={ref} className={className} style={style} {...props}>
      {children}
    </form>
  )),

  input: React.forwardRef<HTMLInputElement, any>(({ className, style, ...props }, ref) => (
    <input ref={ref} className={className} style={style} {...props} />
  )),

  textarea: React.forwardRef<HTMLTextAreaElement, any>(({ children, className, style, ...props }, ref) => (
    <textarea ref={ref} className={className} style={style} {...props}>
      {children}
    </textarea>
  )),

  select: React.forwardRef<HTMLSelectElement, any>(({ children, className, style, ...props }, ref) => (
    <select ref={ref} className={className} style={style} {...props}>
      {children}
    </select>
  )),

  img: React.forwardRef<HTMLImageElement, any>(({ className, style, ...props }, ref) => (
    <img ref={ref} className={className} style={style} {...props} />
  )),

  a: React.forwardRef<HTMLAnchorElement, any>(({ children, className, style, ...props }, ref) => (
    <a ref={ref} className={className} style={style} {...props}>
      {children}
    </a>
  )),

  h1: React.forwardRef<HTMLHeadingElement, any>(({ children, className, style, ...props }, ref) => (
    <h1 ref={ref} className={className} style={style} {...props}>
      {children}
    </h1>
  )),

  h2: React.forwardRef<HTMLHeadingElement, any>(({ children, className, style, ...props }, ref) => (
    <h2 ref={ref} className={className} style={style} {...props}>
      {children}
    </h2>
  )),

  h3: React.forwardRef<HTMLHeadingElement, any>(({ children, className, style, ...props }, ref) => (
    <h3 ref={ref} className={className} style={style} {...props}>
      {children}
    </h3>
  )),

  section: React.forwardRef<HTMLElement, any>(({ children, className, style, ...props }, ref) => (
    <section ref={ref} className={className} style={style} {...props}>
      {children}
    </section>
  )),

  article: React.forwardRef<HTMLElement, any>(({ children, className, style, ...props }, ref) => (
    <article ref={ref} className={className} style={style} {...props}>
      {children}
    </article>
  )),

  nav: React.forwardRef<HTMLElement, any>(({ children, className, style, ...props }, ref) => (
    <nav ref={ref} className={className} style={style} {...props}>
      {children}
    </nav>
  )),

  header: React.forwardRef<HTMLElement, any>(({ children, className, style, ...props }, ref) => (
    <header ref={ref} className={className} style={style} {...props}>
      {children}
    </header>
  )),

  footer: React.forwardRef<HTMLElement, any>(({ children, className, style, ...props }, ref) => (
    <footer ref={ref} className={className} style={style} {...props}>
      {children}
    </footer>
  )),

  main: React.forwardRef<HTMLElement, any>(({ children, className, style, ...props }, ref) => (
    <main ref={ref} className={className} style={style} {...props}>
      {children}
    </main>
  )),
};

export const AnimatePresence: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <>{children}</>
);

motion.div.displayName = 'motion.div';
motion.button.displayName = 'motion.button';
motion.span.displayName = 'motion.span';
motion.label.displayName = 'motion.label';
motion.p.displayName = 'motion.p';
motion.tr.displayName = 'motion.tr';
motion.td.displayName = 'motion.td';
motion.th.displayName = 'motion.th';
motion.table.displayName = 'motion.table';
motion.tbody.displayName = 'motion.tbody';
motion.thead.displayName = 'motion.thead';
motion.ul.displayName = 'motion.ul';
motion.li.displayName = 'motion.li';
motion.form.displayName = 'motion.form';
motion.input.displayName = 'motion.input';
motion.textarea.displayName = 'motion.textarea';
motion.select.displayName = 'motion.select';
motion.img.displayName = 'motion.img';
motion.a.displayName = 'motion.a';
motion.h1.displayName = 'motion.h1';
motion.h2.displayName = 'motion.h2';
motion.h3.displayName = 'motion.h3';
motion.section.displayName = 'motion.section';
motion.article.displayName = 'motion.article';
motion.nav.displayName = 'motion.nav';
motion.header.displayName = 'motion.header';
motion.footer.displayName = 'motion.footer';
motion.main.displayName = 'motion.main';
